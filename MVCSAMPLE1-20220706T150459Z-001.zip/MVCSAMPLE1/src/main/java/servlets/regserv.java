package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.regbean;
import Daos.regdao;

/**
 * servlet implementation class regserv
 */
@WebServlet("/regserv")
public class regserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public regserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("doGet Method");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		System.out.println("hai in dopost");
		String action=request.getParameter("action");
		System.out.println("action : " +action);
		regdao rd=new regdao();
		HttpSession sobj=request.getSession();//create an ojct for session
		System.out.println("HttpSession : " +sobj);
		if(action.equals("reg"))
		{
			
			String Name=request.getParameter("name");
			String Phno=request.getParameter("phno");
			System.out.println("Name: " +Name);
			System.out.println("Phno : " +Phno);
			regbean rb=new regbean();
			rb.setName(Name);
			rb.setPhno(Phno);
			String n=rd.regUser(rb);
			System.out.println("regUser : " +n);
			if(n.equals("success"))
			{
				ArrayList<regbean> arb=rd.viewUser();
				sobj.setAttribute("list", arb);
				request.getRequestDispatcher("View.jsp").forward(request, response);
				
			}
			
		}
		if(action.equals("login"))
		{
			String id=request.getParameter("id");
			regbean rgb=new regbean();
			rgb.setId(id);
			ArrayList<regbean> arb=rd.loginUser(rgb);
			sobj.setAttribute("list", arb);
			System.out.println("Login user" +arb);
			request.getRequestDispatcher("View.jsp").forward(request,response);
			
		}
		if(action.equals("update"))
		{
			String id=request.getParameter("id");
			System.out.println("Id in Update:"+id);
			regbean rgb=new regbean();
			rgb.setId(id);
			ArrayList<regbean> arb=rd.updateUser(rgb);
			sobj.setAttribute("list", arb);
			//System.out.println(arb);
			request.getRequestDispatcher("UpdateForm1.jsp").forward(request, response);
		}
		if(action.equals("up"))
			{
			String id=request.getParameter("id");
			String Name=request.getParameter("name");
			String Phno=request.getParameter("phno");
			//System.out.println("Id in Up:" +id);
			//System.out.println("Name in Up :"+Name);
			//System.out.println("Phno in Update:" +Phno);
			regbean rb=new regbean();
			rb.setName(Name);
			rb.setPhno(Phno);
			rb.setId(id);
			String n=rd.upUser(rb);
			System.out.println("n in up:"+n);
			if(n.equals("success"))
			{
				ArrayList<regbean> arb=rd.viewUser();
				sobj.setAttribute("list", arb);
				request.getRequestDispatcher("View.jsp").forward(request, response);
			}
		}
		if(action.equals("delete"))
		{
		String id=request.getParameter("id");
		regbean rb=new regbean();
		rb.setId(id);
		String n=rd.delUser(rb);
		if(n.equals("success"))
		{
			ArrayList<regbean> arb=rd.viewUser();
			System.out.println("Session Object:"+sobj);
			sobj.setAttribute("list", arb);
			System.out.println("Session Object after adding arraylist:" +sobj);
			request.getRequestDispatcher("View.jsp").forward(request, response);
		}
	}
		
		}
}
