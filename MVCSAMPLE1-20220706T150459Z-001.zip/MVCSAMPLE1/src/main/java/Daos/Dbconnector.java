package Daos;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class Dbconnector {
	public Connection connect;
	public Connection dbconnect()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}//method to register java with driver pack
		catch(ClassNotFoundException e)  
		{
			System.out.println("Class Not found");
		}
		try
		{
			connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/suriya","root","");
		}
		catch(SQLException e)
		
		{
			System.out.println(e);
		}
		return connect;     //datatype connection so it returns connect
		
	}


	}


