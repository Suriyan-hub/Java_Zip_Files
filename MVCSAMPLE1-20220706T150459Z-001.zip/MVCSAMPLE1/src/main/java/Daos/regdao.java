package Daos;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.ArrayList;

	import Bean.regbean;
	import Daos.Dbconnector;
	public class regdao {
		Dbconnector db=new Dbconnector();
		Connection con=null;
		ResultSet rs=null;
		Statement st=null;
		PreparedStatement ps=null;
		public String regUser(regbean rb)
		{
			String query="insert into student1(name,phno) values(?,?)";
			try
			{
			con=db.dbconnect(); //to connect with db
			ps=con.prepareStatement(query); //query is java so it is converted into sql 
			ps.setString(1,rb.getName());//passing value for first ? no relation with db id
			ps.setString(2,rb.getPhno());//for second ?  
			int i=ps.executeUpdate();
			System.out.println("i : " +i);
			if(i!=0)
			{
				return "success";
			}
		}
		catch(Exception e)
		{
		System.out.println(e);	
		}
			return "";
		
		}
		public ArrayList<regbean> loginUser(regbean rb) 
		{
			ArrayList<regbean> list=new ArrayList<regbean>();
			try
			{
				String query="select * from student1 where id='"+rb.getId()+"'";
				con=db.dbconnect();
				st=con.createStatement();
				rs=st.executeQuery(query);
				while(rs.next())
				{
					rb.setId(rs.getString("id"));
					rb.setName(rs.getString("name"));
					rb.setPhno(rs.getString("phno"));
					//System.out.println("ArrayList : " +list.add(rb));
					list.add(rb);
				}
			}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
			return list;
		}
		public ArrayList<regbean> viewUser() 
		{
			ArrayList<regbean> list=new ArrayList<regbean>();
			try
			{
				String query="select * from student1";
				con=db.dbconnect();
				st=con.createStatement();
				rs=st.executeQuery(query);
				while(rs.next())
				{
					regbean rb=new regbean();
					rb.setId(rs.getString("id"));
					rb.setName(rs.getString("name"));
					rb.setPhno(rs.getString("phno"));
					//System.out.println("ArrayList : " +list.add(rb));
					list.add(rb);
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return list;
		}
		public ArrayList<regbean> updateUser(regbean rgb) 
		{
			ArrayList<regbean> list=new ArrayList<regbean>();
			try
			{
				String query="select * from student1 where id='"+rgb.getId()+"'";
				con=db.dbconnect();
				st=con.createStatement();
				rs=st.executeQuery(query);
				while(rs.next())
				{
					
					rgb.setId(rs.getString("id"));
					rgb.setName(rs.getString("name"));
					rgb.setPhno(rs.getString("phno"));
					list.add(rgb);
				}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return list;
		}
		public String delUser(regbean rb) 
		{
			String query="delete from student1 where id='"+rb.getId()+"'";
			try
			{
			con=db.dbconnect();
			ps=con.prepareStatement(query); 
			
			int i=ps.executeUpdate();
			if(i!=0)
			{
				return "success";
			}
		}
		catch(Exception e)
		{
		System.out.println(e);	
		}
			return "";
		}
		public String upUser(regbean rb) {
			String query="update student1 set name=?,phno=? where id='"+rb.getId()+"'";
			try
			{
			con=db.dbconnect(); //to connect with db
			ps=con.prepareStatement(query); //query is java so it is converted into sql 
			ps.setString(1,rb.getName());//passing value for first ? no relation with db id
			ps.setString(2,rb.getPhno());//for second ?  
			//System.out.println("preparedstatementObject:" + ps.setString(1, rb.getName());
			int i=ps.executeUpdate();
			System.out.println("i in regdao" +i);
			if(i!=0)
			{
				return "success";
			}
		}
		catch(Exception e)
		{
		System.out.println(e);	
		}
			return "";
		}
	}

	

